// needed to make CI pass

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Some test to make CI pass', () {
    expect(1, 1);
  });
}
