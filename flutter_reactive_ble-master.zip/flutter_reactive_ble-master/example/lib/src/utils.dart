// ignore: avoid_print
void log(String text) => print("[FlutterReactiveBLEApp] $text");
