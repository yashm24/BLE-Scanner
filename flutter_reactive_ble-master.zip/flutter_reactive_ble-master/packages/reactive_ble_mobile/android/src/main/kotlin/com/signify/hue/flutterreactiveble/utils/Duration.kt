package com.signify.hue.flutterreactiveble.utils

import java.util.concurrent.TimeUnit

data class Duration(val value: Long, val unit: TimeUnit)
