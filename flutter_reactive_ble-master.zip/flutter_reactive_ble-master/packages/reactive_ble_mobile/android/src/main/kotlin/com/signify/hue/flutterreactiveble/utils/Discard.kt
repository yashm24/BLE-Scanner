package com.signify.hue.flutterreactiveble.utils

@Suppress("unused")
fun Any?.discard() = Unit
